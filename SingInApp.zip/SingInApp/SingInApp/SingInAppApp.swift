//
//  SingInAppApp.swift
//  SingInApp
//
//  Created by Ahmed Salah on 14/09/2022.
//

import SwiftUI
import Firebase

@main
struct SingInAppApp: App {
    
    init(){
        FirebaseApp.configure()
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
