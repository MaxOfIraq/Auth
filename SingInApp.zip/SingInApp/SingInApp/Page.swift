//
//  Page.swift
//  SingInApp
//
//  Created by Ahmed Salah on 14/09/2022.
//

import SwiftUI
import Firebase

struct Page: View {
    
    @State var showAleart = false
    
    var body: some View {
        
        VStack{
            Button("Sing Out"){
                try! Auth.auth().signOut()
                showAleart = true
            }.alert("Done Sing Out , Pleass re Open the Applecation",isPresented: $showAleart){
                Button("Ok", role: .cancel){}
            }
        }
    }
}

struct Page_Previews: PreviewProvider {
    static var previews: some View {
        Page()
    }
}
