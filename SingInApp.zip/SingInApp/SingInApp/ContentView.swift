//
//  ContentView.swift
//  SingInApp
//
//  Created by Ahmed Salah on 14/09/2022.
//

import SwiftUI
import Firebase

struct ContentView: View {
    
    @State var email = ""
    @State var password = ""
    @State var isLogIn = false
    
    
    @State var fullScreen : Bool = false
    
    var body: some View {
        if isLogIn{
            Page()
        }else{
            contant
        }
    }
    
    var contant: some View{
        VStack{
            
            TextField("Enter Email", text: $email)
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)
                .padding()
            
            
            SecureField("Enter Your password", text: $password)
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)
                .padding()
            
            
            Button("Log In"){
                LogIn()
            }
            .frame(width: 150, height: 50)
            .background(Color.black)
            .foregroundColor(Color.white)
            .cornerRadius(10)
            
            Spacer()
            
            
            Button("Creat Acount"){
                fullScreen.toggle()
            }.fullScreenCover(isPresented: $fullScreen) {
                CreatAcount()
            }

            
        }.onAppear{
            Auth.auth().addStateDidChangeListener { auth, user in
                if user != nil{
                    isLogIn.toggle()
                }
            }
        }
    }
    
    
    
    func LogIn(){
        Auth.auth().signIn(withEmail: email, password: password) { auth, err in
            if err != nil{
                print(err!.localizedDescription)
            }
        }
    }
    
    
}






struct CreatAcount : View{
    
    @State var email = ""
    @State var password = ""
    
    var body: some View{
        VStack{
            TextField("Enter Email", text: $email)
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)
                .padding()
            
            
            SecureField("Enter Your password", text: $password)
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)
                .padding()
            
            
            Button("Creat Acount"){
                CreatAcount()
            }
            .frame(width: 150, height: 50)
            .background(Color.black)
            .foregroundColor(Color.white)
            .cornerRadius(10)
            
            Spacer()
        }
    }
    
    func CreatAcount(){
        Auth.auth().createUser(withEmail: email, password: password) { auth, err in
            if err != nil{
                print(err!.localizedDescription)
            }
        }
    }
    
    
}















struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
